//
//  SeekNetManager.m
//  yiNews
//
//  Created by apple-jd12 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "SeekNetManager.h"


/**
 *  http://www.xbiao.com/app/articlelist?&pages=0&type=1&time=1447398493882
 */

#define kSeekListPath @"http://www.xbiao.com/app/articlelist"

@implementation SeekNetManager


+(id)getSeekListWithPageId:(NSInteger)pageId currentTime:(NSTimeInterval)currentTime type:(NSInteger)type completionHandle:(void (^)(id, NSError *))completionHandle{
    NSDictionary *params = @{@"pages":@(pageId),@"type":@(type),@"time":@(currentTime)};
    return [self GET:kSeekListPath parameters:params completionHandler:^(id responseObj, NSError *error) {
        completionHandle([SeekModel objectArrayWithKeyValuesArray:responseObj],error);
    }];
}
@end
