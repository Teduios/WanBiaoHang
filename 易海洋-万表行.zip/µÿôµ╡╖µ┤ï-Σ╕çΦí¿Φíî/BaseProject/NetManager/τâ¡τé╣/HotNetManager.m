//
//  HotNetManager.m
//  yiNews
//
//  Created by apple-jd12 on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "HotNetManager.h"

//http://www.xbiao.com/app/articlelist?&page=0&type=2

#define kHotListPath @"http://www.xbiao.com/app/articlelist"

@implementation HotNetManager

+ (id)getHotListWithPage:(NSInteger)page type:(NSInteger)type completionHandle:(void (^)(id, NSError *))completionHandle{
    NSDictionary *params = @{@"page":@(page),@"type":@(type)};
    return [self GET:kHotListPath parameters:params completionHandler:^(id responseObj, NSError *error) {
        completionHandle([HotModel objectArrayWithKeyValuesArray:responseObj],error);
    }];
}
@end
