//
//  HotNetManager.h
//  yiNews
//
//  Created by apple-jd12 on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "HotModel.h"




@interface HotNetManager : BaseNetManager


+ (id)getHotListWithPage:(NSInteger)page type:(NSInteger)type kCompletionHandle;

@end
