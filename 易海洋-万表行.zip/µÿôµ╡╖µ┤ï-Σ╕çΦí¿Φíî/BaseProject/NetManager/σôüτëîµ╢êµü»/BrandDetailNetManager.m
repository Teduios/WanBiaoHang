//
//  BrandDetailNetManager.m
//  yiNews
//
//  Created by apple-jd12 on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BrandDetailNetManager.h"

//http://www.xbiao.com/app/articlelist?&page=0&type=3&brand=101
#define kBrandDetailPath @"http://www.xbiao.com/app/articlelist"

@implementation BrandDetailNetManager

+ (id)getBrandDetailWithPage:(NSInteger)page type:(NSInteger)type brand:(NSInteger)brand completionHandle:(void (^)(id, NSError *))completionHandle{
    return  [self GET:kBrandDetailPath parameters:@{@"page":@(page),@"type":@(type),@"brand":@(brand)} completionHandler:^(id responseObj, NSError *error) {
        completionHandle([BrandDetailModel objectArrayWithKeyValuesArray:responseObj],error);
    }];
}
@end
