//
//  BrandListNetManager.m
//  yiNews
//
//  Created by apple-jd12 on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BrandListNetManager.h"


//http://www.xbiao.com/app/brandlist

#define kBrandListPath @"http://www.xbiao.com/app/brandlist"

@implementation BrandListNetManager

+ (id)getBrandListCompletionHandle:(void (^)(id, NSError *))completionHandle{
    return [self GET:kBrandListPath parameters:nil completionHandler:^(id responseObj, NSError *error) {
        completionHandle([BrandListModel objectWithKeyValues:responseObj],error);
    }];
}
@end
