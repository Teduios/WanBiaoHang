//
//  BrandSaleNetManager.m
//  yiNews
//
//  Created by apple-jd12 on 15/11/15.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BrandSaleNetManager.h"


#define kBrandSaleListPath @"http://www.xbiao.com/app/brandlist"

@implementation BrandSaleNetManager


+ (id)getBrandSaleListCompletionHandle:(void (^)(id, NSError *))completionHandle{
    return [self GET:kBrandSaleListPath parameters:nil completionHandler:^(id responseObj, NSError *error) {
        
    }];
}
@end
