//
//  BrandSaleNetManager.h
//  yiNews
//
//  Created by apple-jd12 on 15/11/15.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "BrandSaleModel.h"

@interface BrandSaleNetManager : BaseNetManager

+ (id)getBrandSaleListCompletionHandle:(void(^)(id model,NSError *error))completionHandle;

@end
