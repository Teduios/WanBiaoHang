//
//  HotModel.h
//  yiNews
//
//  Created by apple-jd12 on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"


@interface HotModel : BaseModel

@property (nonatomic, copy) NSString *commentCount;

@property (nonatomic, copy) NSString *commentUrl;

@property (nonatomic, copy) NSString *introduction;

@property (nonatomic, copy) NSString *author;

@property (nonatomic, copy) NSString *inputtime;

@property (nonatomic, copy) NSString *url;

@property (nonatomic, copy) NSString *createtypes;

@property (nonatomic, copy) NSString *img;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *contentid;

@property (nonatomic, copy) NSString *updatetime;

@property (nonatomic, copy) NSString *brandId;

@property (nonatomic, copy) NSString *brandName;

@property (nonatomic, assign) NSInteger hits;

@end

