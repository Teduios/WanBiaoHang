//
//  SeekModel.h
//  yiNews
//
//  Created by apple-jd12 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@interface SeekModel : BaseModel

@property (nonatomic, copy) NSString *commentCount;

@property (nonatomic, copy) NSString *commentUrl;

@property (nonatomic, copy) NSString *introduction;

@property (nonatomic, copy) NSString *author;

@property (nonatomic, copy) NSString *inputtime;

@property (nonatomic, copy) NSString *url;//评论

@property (nonatomic, copy) NSString *createtypes;//官网动态

@property (nonatomic, copy) NSString *img;//left

@property (nonatomic, copy) NSString *title;//

@property (nonatomic, copy) NSString *contentid;//详情id

@property (nonatomic, copy) NSString *updatetime;//上传时间

@property (nonatomic, copy) NSString *brandId;//49

@property (nonatomic, copy) NSString *brandName;//名仕

@property (nonatomic, assign) NSInteger hits;

@end

