//
//  SeekModel.m
//  yiNews
//
//  Created by apple-jd12 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "SeekModel.h"

@implementation SeekModel

+ (NSString *)replacedKeyFromPropertyName121:(NSString *)propertyName{
    return [propertyName underlineFromCamel];
}
@end

