//
//  BrandListModel.m
//  yiNews
//
//  Created by apple-jd12 on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BrandListModel.h"

@implementation BrandListModel

+ (NSDictionary *)objectClassInArray{
    return @{@"G" : [BrandListDetailModel class], @"H" : [BrandListDetailModel class], @"W" : [BrandListDetailModel class], @"J" : [BrandListDetailModel class], @"X" : [BrandListDetailModel class], @"K" : [BrandListDetailModel class], @"Y" : [BrandListDetailModel class], @"L" : [BrandListDetailModel class], @"Z" : [BrandListDetailModel class], @"M" : [BrandListDetailModel class], @"N" : [BrandListDetailModel class], @"A" : [BrandListDetailModel class], @"O" : [BrandListDetailModel class], @"B" : [BrandListDetailModel class], @"P" : [BrandListDetailModel class], @"Q" : [BrandListDetailModel class], @"D" : [BrandListDetailModel class], @"R" : [BrandListDetailModel class], @"S" : [BrandListDetailModel class], @"F" : [BrandListDetailModel class], @"T" : [BrandListDetailModel class]};
}
@end


@implementation BrandListDetailModel

@end



