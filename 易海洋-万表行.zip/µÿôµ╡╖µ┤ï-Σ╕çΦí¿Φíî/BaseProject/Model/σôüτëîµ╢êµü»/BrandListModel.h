//
//  BrandListModel.h
//  yiNews
//
//  Created by apple-jd12 on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"


@class BrandListDetailModel;

@interface BrandListModel : BaseModel

@property (nonatomic, strong) NSArray<BrandListDetailModel *> *G;

@property (nonatomic, strong) NSArray<BrandListDetailModel *> *H;

@property (nonatomic, strong) NSArray<BrandListDetailModel *> *W;

@property (nonatomic, strong) NSArray<BrandListDetailModel *> *J;

@property (nonatomic, strong) NSArray<BrandListDetailModel *> *X;

@property (nonatomic, strong) NSArray<BrandListDetailModel *> *K;

@property (nonatomic, strong) NSArray<BrandListDetailModel *> *Y;

@property (nonatomic, strong) NSArray<BrandListDetailModel *> *L;

@property (nonatomic, strong) NSArray<BrandListDetailModel *> *Z;

@property (nonatomic, strong) NSArray<BrandListDetailModel *> *M;

@property (nonatomic, strong) NSArray<BrandListDetailModel *> *N;

@property (nonatomic, strong) NSArray<BrandListDetailModel *> *A;

@property (nonatomic, strong) NSArray<BrandListDetailModel *> *O;

@property (nonatomic, strong) NSArray<BrandListDetailModel *> *B;

@property (nonatomic, strong) NSArray<BrandListDetailModel *> *P;

@property (nonatomic, strong) NSArray<BrandListDetailModel *> *Q;

@property (nonatomic, strong) NSArray<BrandListDetailModel *> *D;

@property (nonatomic, strong) NSArray<BrandListDetailModel *> *R;

@property (nonatomic, strong) NSArray<BrandListDetailModel *> *S;

@property (nonatomic, strong) NSArray<BrandListDetailModel *> *F;

@property (nonatomic, strong) NSArray<BrandListDetailModel *> *T;

@end

@interface BrandListDetailModel : NSObject

@property (nonatomic, assign) NSInteger hot;

@property (nonatomic, copy) NSString *url;

@property (nonatomic, copy) NSString *img;

@property (nonatomic, copy) NSString *name;

@property (nonatomic, copy) NSString *ename;

@property (nonatomic, assign) NSInteger brandid;

@end

