//
//  BrandSaleModel.h
//  yiNews
//
//  Created by apple-jd12 on 15/11/15.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@class BrandSaleListModel;
@interface BrandSaleModel : BaseModel

@property (nonatomic, strong) NSArray<BrandSaleListModel *> *G;

@property (nonatomic, strong) NSArray<BrandSaleListModel *> *H;

@property (nonatomic, strong) NSArray<BrandSaleListModel *> *W;

@property (nonatomic, strong) NSArray<BrandSaleListModel *> *J;

@property (nonatomic, strong) NSArray<BrandSaleListModel *> *X;

@property (nonatomic, strong) NSArray<BrandSaleListModel *> *K;

@property (nonatomic, strong) NSArray<BrandSaleListModel *> *Y;

@property (nonatomic, strong) NSArray<BrandSaleListModel *> *L;

@property (nonatomic, strong) NSArray<BrandSaleListModel *> *Z;

@property (nonatomic, strong) NSArray<BrandSaleListModel *> *M;

@property (nonatomic, strong) NSArray<BrandSaleListModel *> *N;

@property (nonatomic, strong) NSArray<BrandSaleListModel *> *A;

@property (nonatomic, strong) NSArray<BrandSaleListModel *> *O;

@property (nonatomic, strong) NSArray<BrandSaleListModel *> *B;

@property (nonatomic, strong) NSArray<BrandSaleListModel *> *P;

@property (nonatomic, strong) NSArray<BrandSaleListModel *> *Q;

@property (nonatomic, strong) NSArray<BrandSaleListModel *> *D;

@property (nonatomic, strong) NSArray<BrandSaleListModel *> *R;

@property (nonatomic, strong) NSArray<BrandSaleListModel *> *S;

@property (nonatomic, strong) NSArray<BrandSaleListModel *> *F;

@property (nonatomic, strong) NSArray<BrandSaleListModel *> *T;

@end
@interface BrandSaleListModel : NSObject

@property (nonatomic, assign) NSInteger hot;

@property (nonatomic, copy) NSString *url;

@property (nonatomic, copy) NSString *img;

@property (nonatomic, copy) NSString *name;

@property (nonatomic, copy) NSString *ename;

@property (nonatomic, assign) NSInteger brandid;

@end


