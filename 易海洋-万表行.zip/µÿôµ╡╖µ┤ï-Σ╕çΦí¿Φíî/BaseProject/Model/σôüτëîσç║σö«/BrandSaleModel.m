//
//  BrandSaleModel.m
//  yiNews
//
//  Created by apple-jd12 on 15/11/15.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BrandSaleModel.h"

@implementation BrandSaleModel

+ (NSDictionary *)objectClassInArray{
    return @{@"G" : [BrandSaleListModel class], @"H" : [BrandSaleListModel class], @"W" : [BrandSaleListModel class], @"J" : [BrandSaleListModel class], @"X" : [BrandSaleListModel class], @"K" : [BrandSaleListModel class], @"Y" : [BrandSaleListModel class], @"L" : [BrandSaleListModel class], @"Z" : [BrandSaleListModel class], @"M" : [BrandSaleListModel class], @"N" : [BrandSaleListModel class], @"A" : [BrandSaleListModel class], @"O" : [BrandSaleListModel class], @"B" : [BrandSaleListModel class], @"P" : [BrandSaleListModel class], @"Q" : [BrandSaleListModel class], @"D" : [BrandSaleListModel class], @"R" : [BrandSaleListModel class], @"S" : [BrandSaleListModel class], @"F" : [BrandSaleListModel class], @"T" : [BrandSaleListModel class]};
}
@end
@implementation BrandSaleListModel

@end



